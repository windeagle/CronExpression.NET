﻿using System;

namespace CronExpressionTest
{
    internal class Program
    {
        private static void Main()
        {
            GetCronResults("* * * * * *");

            GetCronResults("1 * * * * *");
            GetCronResults("2,3 * * * * *");
            GetCronResults("4-6 * * * * *");
            GetCronResults("0/3 * * * * *");
            GetCronResults("1,2,3,4-6,0/3 * * * * *", 50);

            GetCronResults("0 0 0 L * *");
            GetCronResults("0 0 0 LW * *");
            GetCronResults("0 0 0 15W * *");
            GetCronResults("0 0 0 15W,LW,L * *", 30);

            GetCronResults("0 0 0 * * L");
            GetCronResults("0 0 0 * * 6L");
            GetCronResults("0 0 0 * * 3#3");
            GetCronResults("0 0 0 * * L,6L,3#3", 30);
        }

        private static void GetCronResults(string cronExp, int resultsNum = 10)
        {
            CronExpression.NET.CronExpression cron = new CronExpression.NET.CronExpression(cronExp);
            var d = cron.GetNextDateTime(resultsNum);
            Console.WriteLine("The CronExpression is \"" + cronExp + "\", the first " + resultsNum + " results are:");
            var i = 0;
            foreach (var dateTime in d)
            {
                Console.Write(i++);
                Console.Write(": ");
                Console.WriteLine(dateTime);
            }
            Console.WriteLine();
        }
    }
}